/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
;                                                                     
;                     Software License Agreement                      
;                                                                     
;     �2007 Microchip Technology Inc
;     Mirochip Technology Inc. ("Microchip") licenses this software to 
;     you solely for the use with Microchip Products. The software is
;     owned by Microchip and is protected under applicable copyright
;     laws. All rights reserved.
;
;     SOFTWARE IS PROVIDED "AS IS." MICROCHIP EXPRESSLY DISCLAIMS ANY
;     WARRANTY OF ANY KIND, WHETHER EXPRESS OR IMPLIED, INCLUDING BUT NOT
;     LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
;     PARTICULAR PURPOSE, OR NON-INFRINGEMENT. IN NO EVENT SHALL MICROCHIP
;     BE LIABLE FOR ANY INCIDENTAL, SPECIAL, INDIRECT OR CONSEQUENTIAL
;     DAMAGES, LOST PROFITS OR LOST DATA, HARM TO YOUR EQUIPMENT, COST OF
;     PROCUREMENT OF SUBSTITUTE GOODS, TECHNOLOGY OR SERVICES, ANY CLAIMS
;     BY THIRD PARTIES (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF),
;     ANY CLAIMS FOR INDEMNITY OR CONTRIBUTION, OR OTHER SIMILAR COSTS.
;     
;                                                                
;~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
;	Filename:			    main.c            
;	Date:				    February 21, 2007          
;	File Version:		  	1.0                             
;	Assembled using:		MPLAB IDE 7.51.00.0               
; 	Author:		  	    	Martin Bowman              
;	Company:			    Microchip Technology, Inc.
;~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

#include "p33Fxxxx.h"
#include "i2c.h"

_FGS(GSS_OFF & GWRP_OFF);
_FOSCSEL(FNOSC_PRI & IESO_OFF & TEMP_OFF);
_FOSC(FCKSM_CSDCMD & OSCIOFNC_OFF & POSCMD_HS);
_FWDT(FWDTEN_OFF);


void InitPorts(void);

//This file contains the function prototypes for the i2c function
#define PAGESIZE	32

unsigned char data[PAGESIZE];

/*********************************************************************
* Function:        main()
*
* Input:		None.
*
* Output:		None.
*
* Overview:		Main function loop.  Called on startup by init code
*
* Note:			None
********************************************************************/
int main (void)
{
	unsigned char i;		//Counter

	InitPorts();		//Initialise the IO Ports
						//And setup the DDR registers for correct 
						//IO configuration

    control = CONTROLBYTE;              // Load control byte

    // Byte write/read routines
    address = 0x5A00;                   // Load address with 0x5A00
    data[0] = 0x55;                     // Load data with 0x55
 	
    for (i = 0; i < PAGESIZE; i++)      // Loop through full page
    {
        data[i] = i;     // Initialize array
    }
    //LowDensPageWrite(data,PAGESIZE);    // Write a full page
    //LowDensSequentialRead(data,PAGESIZE);// Read a full page
	while(1)
	{
		LATAbits.LATA0 = 1;
    	HighDensPageWrite(data,PAGESIZE);   // Write a full page
		LATAbits.LATA0 = 0;
	}
	while(1)
	{
    	//LowDensByteWrite(data[0]);          // Write a single byte
		//HighDensByteWrite(data[0]);         // Write a single byte
		HighDensSequentialRead(data,PAGESIZE);// Read a full page
	}

    LowDensByteRead(data);              // Read a single byte
    
    //HighDensByteRead(data);             // Read a single byte

    // Page write/read routines
   
    
	LATAbits.LATA0 = 0;

    while(1);                           // Loop here forever
} // end main(void)


/*********************************************************************
* Function:        InitPorts()
*
* Input:		None.
*
* Output:		None.
*
* Overview:		Initialises the IO ports
*
* Note:			None
********************************************************************/
void InitPorts(void)
{
	//This function initialises the IO ports and sets the TRIS bits for
	//The IO used for the I2C Communication.

	//The I2C device is configure the same as in AN1079, that is the SCL and
	//SDA lines are connected to the I2C1 peripheral, however the peripheral is
	//not used.  Any of the remaining IO pins can be used.
	TRISA = 0x0000;
	TRISB = 0x0000;
	TRISC = 0x0000;
	TRISD = 0x0000;
	TRISE = 0x0000;
	TRISF = 0x0000;
	TRISG = 0x0000;					

	TRISGbits.TRISG2 = 0;		//SCL Line make Output.
	TRISGbits.TRISG3 = 1;
}
