/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
;                                                                     
;                     Software License Agreement                      
;                                                                     
;     �2007 Microchip Technology Inc
;     Mirochip Technology Inc. ("Microchip") licenses this software to 
;     you solely for the use with Microchip Products. The software is
;     owned by Microchip and is protected under applicable copyright
;     laws. All rights reserved.
;
;     SOFTWARE IS PROVIDED "AS IS." MICROCHIP EXPRESSLY DISCLAIMS ANY
;     WARRANTY OF ANY KIND, WHETHER EXPRESS OR IMPLIED, INCLUDING BUT NOT
;     LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
;     PARTICULAR PURPOSE, OR NON-INFRINGEMENT. IN NO EVENT SHALL MICROCHIP
;     BE LIABLE FOR ANY INCIDENTAL, SPECIAL, INDIRECT OR CONSEQUENTIAL
;     DAMAGES, LOST PROFITS OR LOST DATA, HARM TO YOUR EQUIPMENT, COST OF
;     PROCUREMENT OF SUBSTITUTE GOODS, TECHNOLOGY OR SERVICES, ANY CLAIMS
;     BY THIRD PARTIES (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF),
;     ANY CLAIMS FOR INDEMNITY OR CONTRIBUTION, OR OTHER SIMILAR COSTS.
;     
;                                                                
;~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
;	Filename:			    i2c_Func.c            
;	Date:				    February 21, 2007          
;	File Version:		  	1.0                             
;	Assembled using:		MPLAB IDE 7.51.00.0               
; 	Author:		  	    	Martin Bowman              
;	Company:			    Microchip Technology, Inc.
;~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
#include "p33Fxxxx.h"
#include "i2c.h"

/** V A R I A B L E S **********************************************/
unsigned char control;              // Control byte variable
unsigned int address;               // Address word variable

//Function Prototypes
void bit_in(unsigned char *data);		//Bit Input function
void bit_out(unsigned char data);		//Bit Out function

/********************************************************************
 * Function:        void bstart(void)
 *
 * Description:     This function generates an I2C Start condition.
 *******************************************************************/
void bstart(void)
{
    SDA_TRIS = 1;                   // Ensure SDA is high
    SCL = 1;                        // Ensure SCL is high
	Nop();
    SDA_TRIS = 0;                   // Configure SDA as an output
    SDA = 0;                        // Pull SDA low
	Nop();
    SCL = 0;                        // Pull SCL low
    
} // end bstart(void)

/********************************************************************
 * Function:        void bstop(void)
 *
 * Description:     This function generates an I2C Stop condition.
 *******************************************************************/
void bstop(void)
{
    SCL = 0;                        // Ensure SCL is low
    SDA_TRIS = 0;                   // Configure SDA as an output
    SDA = 0;                        // Ensure SDA low
	Nop();
    SCL = 1;                        // Pull SCL high
	Nop();
    SDA_TRIS = 1;                   // Allow SDA to be pulled high
} // end bstop(void)

/********************************************************************
 * Function:        void bit_out(unsigned char data)
 *
 * Description:     This function outputs a bit to the I2C bus.
 *******************************************************************/
void bit_out(unsigned char data)
{
    SCL = 0;                        // Ensure SCL is low
    if (data & 0x80)                // Check if next bit is high
    {
        SDA_TRIS = 1;               // Release SDA to be pulled high
		Nop();
		Nop();
    }
    else
    {
        SDA_TRIS = 0;               // Configure SDA as an output
        SDA = 0;                    // Pull SDA low
		Nop();
		Nop();
    }
    SCL = 1;                        // Pull SCL high to clock bit
	Nop();
	Nop();
	Nop();
    SCL = 0;                        // Pull SCL low for next bit
} // end bit_out(unsigned char data)

/********************************************************************
 * Function:        void bit_in(unsigned char *data)
 *
 * Description:     This function inputs a bit from the I2C bus.
 *******************************************************************/
void bit_in(unsigned char *data)
{
    SCL = 0;                        // Ensure SCL is low	
	Nop();
    SDA_TRIS = 1;                   // Configure SDA as an input
	Nop();
    SCL = 1;                        // Bring SCL high to begin transfer
    *data &= 0xFE;                  // Assume next bit is low
    if (SDA)                        // Check if SDA is high
    {
        *data |= 0x01;              // If high, set next bit
    }
	Nop();
    SCL = 0;                        // Bring SCL low again
} // end bit_in(unsigned char *data)

/********************************************************************
 * Function:        unsigned char byte_out(unsigned char data)
 *
 * Description:     This function outputs a byte to the I2C bus.
 *                  It also receives the ACK bit and returns 0 if
 *                  successfully received, or 1 if not.
 *******************************************************************/
unsigned char byte_out(unsigned char data)
{
    unsigned char i;                // Loop counter
    unsigned char ack;              // ACK bit

    ack = 0;
    for (i = 0; i < 8; i++)         // Loop through each bit
    {
        bit_out(data);              // Output bit
        data = data << 1;           // Shift left for next bit
    }
    bit_in(&ack);                   // Input ACK bit

    return ack;
} // end byte_out(unsigned char data)

/********************************************************************
 * Function:        unsigned char byte_in(unsigned char ack)
 *
 * Description:     This function inputs a byte from the I2C bus.
 *                  Depending on the value of ack, it will also
 *                  transmit either an ACK or a NAK bit.
 *******************************************************************/
unsigned char byte_in(unsigned char ack)
{
    unsigned char i;                // Loop counter
    unsigned char retval;           // Return value

    retval = 0;
    for (i = 0; i < 8; i++)         // Loop through each bit
    {
        retval = retval << 1;       // Shift left for next bit
        bit_in(&retval);            // Input bit
    }
    bit_out(ack);                   // Output ACK/NAK bit

    return retval;
} // end byte_in(void)

/********************************************************************
 * Function:        void LowDensByteWrite(unsigned char data)
 *
 * Description:     This function writes a single byte to a
 *                  low-density (<= 16 Kb) serial EEPROM device.
 *
 * Dependencies:    'control' contains the control byte
 *                  'address' contains the address word
 *******************************************************************/
void LowDensByteWrite(unsigned char data)
{
    unsigned char temp_control;     // Temp. variable for control byte

    // Merge block bits with control byte
    temp_control = (control & 0xF1) | ((address >> 7) & 0x0E);

    bstart();                       // Generate Start condition
    byte_out(temp_control);         // Output control byte
    byte_out((unsigned char)address);// Output address LSB
    byte_out(data);                 // Output data byte
    bstop();                        // Generate Stop condition
    ACK_Poll();                     // Begin ACK polling
} // end LowDensByteWrite(unsigned char data)

/********************************************************************
 * Function:        void HighDensByteWrite(unsigned char data)
 *
 * Description:     This function writes a single byte to a
 *                  high-density (>= 32 Kb) serial EEPROM device.
 *
 * Dependencies:    'control' contains the control byte
 *                  'address' contains the address word
 *******************************************************************/
void HighDensByteWrite(unsigned char data)
{
    bstart();                       // Generate Start condition
    byte_out(control);              // Output control byte
    byte_out((unsigned char)(address>>8));// Output address MSB
    byte_out((unsigned char)address);// Output address LSB
    byte_out(data);                 // Output data byte
    bstop();                        // Generate Stop condition
    ACK_Poll();                     // Begin ACK polling
} // end HighDensByteWrite(unsigned char data)

/********************************************************************
 * Function:        void LowDensPageWrite(unsigned char *data,
 *                                        unsigned char numbytes)
 *
 * Description:     This function writes multiple bytes to a
 *                  low-density (<= 16 Kb) serial EEPROM device.
 *
 * Dependencies:    'control' contains the control byte
 *                  'address' contains the address word
 *******************************************************************/
void LowDensPageWrite(unsigned char *data, unsigned char numbytes)
{
    unsigned char i;                // Loop counter
    unsigned char temp_control;     // Temp. variable for control byte

    // Merge block bits with control byte
    temp_control = (control & 0xF1) | ((address >> 7) & 0x0E);

    bstart();                       // Generate Start condition
    byte_out(temp_control);         // Output control byte
    byte_out((unsigned char)address);// Output address LSB
    for (i = 0; i < numbytes; i++)  // Loop through data bytes
    {
        byte_out(data[i]);          // Output next data byte
    }
    bstop();                        // Generate Stop condition
    ACK_Poll();                     // Begin ACK polling
} // end LowDensPageWrite(unsigned char *data, unsigned char numbytes)

/********************************************************************
 * Function:        void HighDensPageWrite(unsigned char *data,
 *                                         unsigned char numbytes)
 *
 * Description:     This function writes multiple bytes to a
 *                  high-density (>= 32 Kb) serial EEPROM device.
 *
 * Dependencies:    'control' contains the control byte
 *                  'address' contains the address word
 *******************************************************************/
void HighDensPageWrite(unsigned char *data, unsigned char numbytes)
{
    unsigned char i;                // Loop counter

    bstart();                       // Generate Start condition
    byte_out(control);              // Output control byte
    byte_out((unsigned char)(address>>8));// Output address MSB
    byte_out((unsigned char)address);// Output address LSB
    for (i = 0; i < numbytes; i++)  // Loop through data bytes
    {
        byte_out(data[i]);          // Output next data byte
    }
    bstop();                        // Generate Stop condition
    ACK_Poll();                     // Begin ACK polling
} // end HighDensPageWrite(unsigned char *data, unsigned char numbytes)

/********************************************************************
 * Function:        void LowDensByteRead(unsigned char *data)
 *
 * Description:     This function reads a single byte from a
 *                  low-density (<= 16 Kb) serial EEPROM device.
 *
 * Dependencies:    'control' contains the control byte
 *                  'address' contains the address word
 *******************************************************************/
void LowDensByteRead(unsigned char *data)
{
    unsigned char temp_control;     // Temp. variable for control byte

    // Merge block bits with control byte
    temp_control = (control & 0xF1) | ((address >> 7) & 0x0E);

    bstart();                       // Generate Start condition
    byte_out(temp_control);         // Output control byte
    byte_out((unsigned char)address);// Output address LSB
    bstart();                       // Generate Start condition
    byte_out(temp_control | 0x01);  // Output control byte
    *data = byte_in(NAKBIT);        // Input data byte
    bstop();                        // Generate Stop condition
} // end LowDensByteRead(unsigned char data)

/********************************************************************
 * Function:        void HighDensByteRead(unsigned char *data)
 *
 * Description:     This function reads a single byte from a
 *                  high-density (>= 32 Kb) serial EEPROM device.
 *
 * Dependencies:    'control' contains the control byte
 *                  'address' contains the address word
 *******************************************************************/
void HighDensByteRead(unsigned char *data)
{
    bstart();                       // Generate Start condition
    byte_out(control);              // Output control byte
    byte_out((unsigned char)(address>>8));// Output address MSB
    byte_out((unsigned char)address);// Output address LSB
    bstart();                       // Generate Start condition
    byte_out(control | 0x01);       // Output control byte
    *data = byte_in(NAKBIT);        // Input data byte
    bstop();                        // Generate Stop condition
} // end HighDensByteRead(unsigned char data)

/********************************************************************
 * Function:        void LowDensSequentialRead(unsigned char *data,
 *                                             unsigned char numbytes)
 *
 * Description:     This function reads multiple bytes from a
 *                  low-density (<= 16 Kb) serial EEPROM device.
 *
 * Dependencies:    'control' contains the control byte
 *                  'address' contains the address word
 *******************************************************************/
void LowDensSequentialRead(unsigned char *data, unsigned int numbytes)
{
    unsigned int i;                 // Loop counter
    unsigned char temp_control;     // Temp. variable for control byte

    // Merge block bits with control byte
    temp_control = (control & 0xF1) | ((address >> 7) & 0x0E);

    bstart();                       // Generate Start condition
    byte_out(temp_control);         // Output control byte
    byte_out((unsigned char)address);// Output address LSB
    bstart();                       // Generate Start condition
    byte_out(temp_control | 0x01);  // Output control byte
    for (i = 0; i < numbytes; i++)  // Loop through data bytes
    {
        if (i < (numbytes - 1))     // Check if more data will be read
        {
            data[i] = byte_in(ACKBIT); // If not last, input byte & send ACK
        }
        else
        {
            data[i] = byte_in(NAKBIT); // If last byte, input byte & send NAK
        }
    }
    bstop();                        // Generate Stop condition
} // end LowDensSequentialRead(unsigned char *data, unsigned char numbytes)

/********************************************************************
 * Function:        void HighDensSequentialRead(unsigned char *data,
 *                                              unsigned char numbytes)
 *
 * Description:     This function reads multiple bytes from a
 *                  high-density (>= 32 Kb) serial EEPROM device.
 *
 * Dependencies:    'control' contains the control byte
 *                  'address' contains the address word
 *******************************************************************/
void HighDensSequentialRead(unsigned char *data, unsigned int numbytes)
{
    unsigned int i;                 // Loop counter

    bstart();                       // Generate Start condition
    byte_out(control);              // Output control byte
    byte_out((unsigned char)(address>>8));// Output address MSB
    byte_out((unsigned char)address);// Output address LSB
    bstart();                       // Generate Start condition
    byte_out(control | 0x01);       // Output control byte
    for (i = 0; i < numbytes; i++)  // Loop through data bytes
    {
        if (i < (numbytes - 1))     // Check if more data will be read
        {
            data[i] = byte_in(ACKBIT); // If not last, input byte & send ACK
        }
        else
        {
            data[i] = byte_in(NAKBIT); // If last byte, input byte & send NAK
        }
    }
    bstop();                        // Generate Stop condition
} // end HighDensSequentialRead(unsigned char *data, unsigned char numbytes)

/********************************************************************
 * Function:        void ACK_Poll(void)
 *
 * Description:     This function implements Acknowledge polling.
 *
 * Dependencies:    'control' contains the control byte
 *******************************************************************/
void ACK_Poll(void)
{
    unsigned char result;           // Polling result

    result = 1;                     // Initialize result
    do
    {
        bstart();                   // Generate Start condition
        result = byte_out(control); // Output control byte
    } while (result == 1);
    bstop();                        // Generate Stop condition
} // end ACK_Poll(void)
